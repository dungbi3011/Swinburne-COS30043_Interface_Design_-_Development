function validate() {
	var name = document.getElementById("name").value;
	var pwd = document.getElementById("pwd").value;
	var genm = document.getElementById("genm").checked;
	var genf = document.getElementById("genf").checked;
	var email = document.getElementById("email").value;
	var errMsg = ""; /*stores the error message */
	var result = true;
	
	/*check if all required inputs have value */
	if (name == "") {
		errMsg += "Name can not be empty. \n";
	}
	if (pwd == "") {
		errMsg += "Password can not be empty. \n";
	}
	if ((genm == "")&&(genf == "")) {
		errMsg += "A gender must be selected. \n";
	}
	if (email == "") {
		errMsg += "Email must be provided. \n";
	}
	if (pwd.length < 8) {
		errMsg += "Password must contain at least 8 digits. \n" ;
	}
	if (errMsg != "") {
		alert(errMsg);
		result = false;
	}
	return result;
}

function init() {
	var survey = document.getElementById("survey");
	survey.onsubmit = validate;
}

window.onload = init;
		