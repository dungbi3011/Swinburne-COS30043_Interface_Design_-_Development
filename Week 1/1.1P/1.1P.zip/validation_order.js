function validate() {
	var delivery = document.getElementById("delivery").checked;
	var pick_up = document.getElementById("pick_up").checked;
	var delivery_address = document.getElementById("delivery_address").value;
	var billing_address = document.getElementById("billing_address").value;
	var postcode = document.getElementById("postcode").value;
	var contact_number = document.getElementById("contact_number").value;
	var email = document.getElementById("email").value;
	var payment_method1 = document.getElementById("payment_method1").checked;
	var payment_method2 = document.getElementById("payment_method2").checked;
	var credit_card = document.getElementById("credit_card").value;
	var visa = document.getElementById("visa").checked;
	var mastercard = document.getElementById("mastercard").checked;
	var american_express = document.getElementById("american_express").checked;
	var same = document.getElementById("same").checked;
	var errMsg = ""; /*stores the error message */
	var result = true;
	
	/*check if all required inputs have value */
	if ((delivery == "")&&(pick_up == "")) {
		errMsg += "You must select a way to receive your products. \n";
	}
	if ((same == true)&&(delivery_address == "")) {
		errMsg += "Please enter your delivery address first. \n";
	}	
	if (billing_address == "") {
		errMsg += "Billing address must be provided correctly. \n";
	}
	if (postcode == "") {
		errMsg += "Please insert your postcode. \n";
	}
	if (postcode.length != 4) {
		errMsg += "Postcode must contain 4 digits. \n"
	}
	if (contact_number == "") {
		errMsg += "Contact number must be provided. \n";
	}
	if (email == "") {
		errMsg += "Email must be provided for receipt. \n";
	}
	if ((payment_method1 == "")&&(payment_method2 == "")) {
		errMsg += "A payment method must be selected. \n";									
	}
	if ((visa == "")&&(mastercard == "")&&(american_express == "")) {
		errMsg += "Please choose a credit card for your payment. \n";
	}
	if (credit_card == "") {
		errMsg += "Credit card number must be provided. \n";
	}
	if ((visa == true)||(mastercard == true)) { 
		if (credit_card.length < 16) {
			errMsg += "Credit card number must contain at least 16 digits. \n";
		} 
	}
	if (american_express == true) {
		if (credit_card.length < 15) {
			errMsg += "Credit card number must contain at least 15 digits. \n";
		}
	}	
	if (errMsg != "") {
		alert(errMsg);
		result = false;
	}
	return result;
}

function appear1() {
	var delivery_information = document.getElementById("delivery_information");
	var same_address = document.getElementById("same_address");
	if (document.getElementById("delivery").checked == true) {
		delivery_information.style.display = "block";
	} else {
		delivery_information.style.display = "none";
	}
	if (document.getElementById("delivery").checked == true) {
		same_address.style.display = "block";
	} else {
		same_address.style.display = "none";
	}
}

function appear2() {
	var credit_card_information = document.getElementById("credit_card_information");
	if (document.getElementById("payment_method2").checked == true) {
		credit_card_information.style.display = "block";
	} else {
		credit_card_information.style.display = "none";
	}
}

function auto_fill() {
	var same = document.getElementById("same");
	var delivery_address = document.getElementById("delivery_address").value;
	if (same.checked) {
		document.getElementById("billing_address").value = delivery_address;
	} else {
		document.getElementById("billing_address").value = "";
	}
}

function init() {
	var survey = document.getElementById("survey");
	survey.onsubmit = validate;
	document.getElementById("delivery_information").style.display = "none";
	document.getElementById("credit_card_information").style.display = "none";
	document.getElementById("same_address").style.display = "none";
	if (document.getElementById("delivery").checked == true) {
		delivery_information.style.display = "block";
	} else {
		delivery_information.style.display = "none";
	}
}

window.onload = init;