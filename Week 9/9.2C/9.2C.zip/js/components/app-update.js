// app-putdata component
const PutData = {
  template: `
  <!-- Updating mySQL Table With Name as Key -->
  <v-row>
    <v-col cols="12" >

      <v-card class="mx-auto" max-width="90%">
        <v-card-text>
          <!-- Input -->
          <v-form>
            <v-text-field label="Enter the unit code (unchangeable)" v-model="updatecode">
            </v-text-field>
            <v-text-field label="Description" v-model="updatedesc">
            </v-text-field>
            <v-text-field label="Credit Points" v-model="updatecp">
            </v-text-field>
            <v-text-field label="Type" v-model="updatetype">
            </v-text-field>
            <v-btn depressed v-on:click="putData(updatecode,updatedesc,updatecp,updatetype)" color="primary">
              Update
            </v-btn>
          </v-form>
        </v-card-text>
      </v-card>

    </v-col>

  </v-row>

     `,
     //variable initialization
    data: function() {
      return {
        updatecode: '',
        updatedesc: '',
        updatecp: '',
        updatetype: '',
        headers: '',
      }
    },
    methods: {

    putData: function(updatecode,updatedesc,updatecp,updatetype) {

      var postSQLApiURL = '../9.2C/resources/app-update.php';


      var self = this;
      // POST request using fetch with error handling
      const requestOptions = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          code: updatecode,
          desc: updatedesc,
          cp:updatecp,
          type: updatetype
        })
      };

		fetch(postSQLApiURL, requestOptions)
		.then( response =>{
		  //turning the response into the usable data
		  return response.json( );
		})
		.then( data =>{
		  //This is the data you wanted to get from url
		  self.msg="successful";
		})
		.catch(error => {
		  self.err=error
		});

    }

    }
  }
