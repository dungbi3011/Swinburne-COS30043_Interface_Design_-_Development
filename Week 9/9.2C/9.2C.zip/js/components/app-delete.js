// app-deldata  component
const DelData = {
  template: `
  <v-row>
		<v-col cols="12">

			<v-card class="mx-auto" max-width="90%">
				<v-card-text>
					<v-form>
						<v-text-field label="Code" v-model="deletecode">
						</v-text-field>
						<v-btn depressed v-on:click="delData(deletecode)" color="primary">Delete</v-btn>
					</v-form>
				</v-card-text>
			</v-card>

		</v-col>
	</v-row>
           `,
  // variable initialization
  data: function() {
    return {
	  deletecode:'',
      headers: '',
    }
  },

  methods: {

    delData: function(deletecode) {
      var delSQLApiURL = '../9.2C/resources/app-delete.php';

      var self = this;
      // DELETE request using fetch with error handling
      const requestOptions = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          code: deletecode
        })
      };

		 fetch(delSQLApiURL, requestOptions)
		.then( response =>{
			//turning the response into the usable data
			return response.json( );
		})
		.then( data =>{
		  //This is the data you wanted to get from url
		   self.msg = "Data deleted successfully"

		})
		.catch(error => {
			self.msg = 'There was an error!';
			self.statusText = error;
		});

    }
  }
}
