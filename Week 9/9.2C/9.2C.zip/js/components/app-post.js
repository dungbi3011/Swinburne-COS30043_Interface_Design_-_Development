// app-postdata component

const PostData = {
  template: `
  <v-row>
    <v-col cols="12" >

    <v-card class="mx-auto" max-width="90%">
      <v-card-text>
      <v-form v-model="valid" ref="myForm">

          <v-text-field :rules="CodeRules" type="text" label="Code" v-model="postcode"></v-text-field>
          <v-text-field :rules="DescRules" type="text" label="Description" v-model="postdesc"></v-text-field>
          <v-text-field :rules="CreditRules" type="number" label="Credit Points" v-model="postnum"></v-text-field>
          <v-text-field :rules="TypeRules" type="text" label="Type" v-model="posttype"></v-text-field>

        <v-btn
        :disabled="!valid" type="submit" 
        v-on:click="postData(postcode, postdesc, postnum,posttype)"
        color="primary">
        Add
        </v-btn>

      </v-form>
      </v-card-text>

    </v-card>

    </v-col>
  </v-row>`,

  data: function() {
    return {
      postcode: '',
      postdesc: '',
      postnum: '',
      posttype: '',
      valid: true,
      CodeRules: [
          v => !!v || 'Code is required',
          v => (v && v.length == 8) || 'Code must be 8 characters',
          v => /^[A-Z]{3}[0-9]{5}/.test(v) || 'Code only has 3 capitalized letters on start and 5 numbers'
      ],
      DescRules: [
          v => !!v || 'Description is required'
      ],
      CreditRules: [
          v => !!v || 'Credit points are required',
          v => /^[0-9]/.test(v) || 'Credit points are numbers only'
      ],
      TypeRules: [
          v => !!v || 'Unit Type is required'
      ],
    }
  },
  methods: {

    postData: function(postcode, postdesc, postnum,posttype) {
      //define url for api
      var postSQLApiURL = '../9.2C/resources/app-post.php';
      var self = this;

      const requestOptions = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          code: postcode,
          desc: postdesc,
          cp:postnum,
          type: posttype
        })
      };

		fetch(postSQLApiURL, requestOptions)
		.then( response =>{
		  //turning the response into the usable data
		  return response.json( );
		})
		.then( data =>{
		  //This is the data you wanted to get from url
		   self.msg = "Data Inserted Successfully."  ;
		})
		.catch(error => {
		   self.msg = 'There was an error!' + error;
		});

    }
  }
};