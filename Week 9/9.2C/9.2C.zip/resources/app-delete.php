<?php
include_once("settings.php");

$method = $_SERVER['REQUEST_METHOD'];
$request = explode('/', trim($_SERVER['REQUEST_URI'],'/'));
$input = json_decode(file_get_contents('php://input'),true);  // json string to associative array(true)

//$conn = connecting to database//
mysqli_set_charset($conn,'utf8');

// Inputs
$inputCode = $input['code'];

$stmt = $conn->prepare("DELETE FROM unit_information WHERE `code`=?;");
$stmt->bind_param("s", $inputCode);

if($stmt->execute()){
  echo "New records deleted successfully";
} 

//close the db connection
mysqli_close($conn);
?>
