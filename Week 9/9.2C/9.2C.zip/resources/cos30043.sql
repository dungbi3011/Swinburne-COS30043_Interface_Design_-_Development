--
-- Database: `cos30043`
--

-- --------------------------------------------------------

--
-- Table structure for table `unit_information`
--

CREATE TABLE `unit_information` (
  `UnitId` int NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `desc` varchar(70) NOT NULL,
  `cp` INT(3) NOT NULL,
  `type` varchar(60) NOT NULL,
  PRIMARY KEY (`UnitId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit_information`
--

INSERT INTO `unit_information` (`code`, `desc`, `cp`, `type`) VALUES
("ICT10001", "Problem Solving with ICT"                        , 15, 'Core'                 ),
("COS10005", "Web Development"                                 , 15, 'Core'                 ),
("INF10003", "Introduction to Business Information Systems"    , 15, 'Core'                 ),
("INF10002", "Database Analysis and Design"                    , 15, 'Core'                 ),
("COS10009", "Introduction to Programming"                     , 15, 'Core'                 ),
("INF30029", "Information Technology Project Management"       , 15, 'Core'                 ),
("ICT30005", "Professional Issues in Information Technology"   , 15, 'Core'                 ),
("ICT30001", "Information Technology Project"                  , 15, 'Core'                 ),
("COS20001", "User-Centred Design"                             , 15, 'Software Development' ),
("TNE10005", "Network Administration"                          , 15, 'Software Development' ),
("COS20016", "Operating System Configuration"                  , 15, 'Software Development' ),
("SWE20001", "Development Project 1 - Tools and Practices"     , 15, 'Software Development' ),
("COS20007", "Object Oriented Programming"                     , 15, 'Software Development' ),
("COS30015", "IT Security"                                     , 15, 'Software Development' ),
("COS30043", "Interface Design and Development"                , 15, 'Software Development' ),
("COS30017", "Software Development for Mobile Devices"         , 15, 'Software Development' ),
("INF20012", "Enterprise Systems"                              , 15, 'Software Development' ),
("ACC10007", "Financial Information for Decision Making"       , 15, 'Software Development' ),
("INF20003", "Requirements Analysis and Modelling"             , 15, 'Systems Analysis'     ),
("ACC20014", "Management Decision Making"                      , 15, 'Systems Analysis'     ),
("INF30005", "Business Process Management"                     , 15, 'Systems Analysis'     ),
("INF30003", "Business Information Systems Analysis"           , 15, 'Systems Analysis'     ),
("INF30020", "Information Systems Risk and Security"           , 15, 'Systems Analysis'     ),
("INF30001", "Systems Acquisition & Implementation Management" , 15, 'Systems Analysis'     );


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'dungbi3011', 'Quocdung03');
