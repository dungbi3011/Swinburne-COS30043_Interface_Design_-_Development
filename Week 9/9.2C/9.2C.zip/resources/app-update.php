<?php
include_once("settings.php");

$method = $_SERVER['REQUEST_METHOD'];
$request = explode('/', trim($_SERVER['REQUEST_URI'],'/'));
$input = json_decode(file_get_contents('php://input'),true);  // json string to associative array(true)

//$conn = connecting to database//
mysqli_set_charset($conn,'utf8');

// Inputs
$inputCode = $input['code'];
$inputDesc = $input['desc'];
$inputCredit = $input['cp'];
$inputType = $input['type'];

$stmt = $conn->prepare("UPDATE unit_information
                        SET `desc` =  ?, cp = ?, type = ?
                        WHERE code = ?;"
                      );
$stmt->bind_param("siss", $inputDesc, $inputCredit, $inputType, $inputCode);

if($stmt->execute()){
  echo "New records modified successfully";
} 

//close the db connection
mysqli_close($conn);
?>
