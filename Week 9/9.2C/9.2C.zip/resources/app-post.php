<?php
include_once("settings.php");

$method = $_SERVER['REQUEST_METHOD'];
$request = explode('/', trim($_SERVER['REQUEST_URI'],'/'));
$input = json_decode(file_get_contents('php://input'),true);  // json string to associative array(true)

//$conn = connecting to database//
mysqli_set_charset($conn,'utf8');

// Inputs
$inputCode = $input['code'];
$inputDesc = $input['desc'];
$inputCredit = $input['cp'];
$inputType = $input['type'];

$stmt = $conn->prepare("INSERT INTO unit_information(code, `desc`, cp, `type`) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssis", $inputCode, $inputDesc, $inputCredit, $inputType);

if($stmt->execute()){
  echo "New records created successfully";
} 

//close the db connection
mysqli_close($conn);
?>
