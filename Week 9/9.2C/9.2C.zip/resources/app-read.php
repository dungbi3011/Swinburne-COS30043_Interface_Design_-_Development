<?php
include_once("settings.php");

$sql = "select * from unit_information";
//$conn = connecting to database//
$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

$emparray = array();

//inserting units from database (settings.php) into array
while($row = mysqli_fetch_assoc($result)) {
    $emparray[] = $row;
}

echo json_encode($emparray);

//close the db connection
mysqli_close($conn);
?>
